<?php

if ( !isset($_POST['login']) || !isset($_POST['senha']) ) {
    header('Location: exe14.php?mensagem=0');
    die();
}

$login = $_POST['login'];
$senha = $_POST['senha'];

if ($login != 'lgapontes' || $senha != '123eja') {
    header('Location: exe14.php?mensagem=0');
    die();
} else {
    header('Location: exe14.php?mensagem=1');
    die();
}
