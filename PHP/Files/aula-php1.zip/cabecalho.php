<?php
    $variavel = $variavel + 1;
?>

<header>
    Título da página <?= $variavel ?>
</header>
