<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="utf-8">
        <title>PHP</title>
        <style>
            header {
                display: block;
                line-height: 50px;
                width: 100%;
                position: fixed;
                left: 0;
                top: 0;
                background-color: #3f4354;
                box-shadow: 0 3px 3px black;
                color: white;
                font-size: 1.4em;
                text-align: center;
                font-weight: bold;
            }
            main {
                margin-top: 60px;
                font-size: 1.4em;
            }
        </style>
    </head>
    <body>
        <?php
            include 'cabecalho.php';
            include 'cabecalho.php';

            require 'cabecalho.php';
            require 'cabecalho.php';

            require_once 'cabecalho.php';
            require_once 'cabecalho.php';
        ?>
        <main>
            Outros trechos da página.....
        </main>
    </body>
</html>
