<?php

session_start();
session_destroy();

session_start();
$_SESSION['mensagem-sucesso'] = 'Logout realizado com sucesso!';

header('Location: ../index.php');
die();
