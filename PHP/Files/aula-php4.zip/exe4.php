<?php
    header('Access-Control-Allow-Origin: *');

    $dados = array(
        "mensagem" => "Minha primeira API!"
    );

    header('Content-Type: application/json');
    echo json_encode($dados);
    die();
