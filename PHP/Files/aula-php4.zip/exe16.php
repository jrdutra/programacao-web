<?php
    header('Access-Control-Allow-Origin: *');

    class Cliente implements JsonSerializable {
        private $nome;
        private $idade;
        private $aposentado;
        
        public function __construct($nome,$idade,$aposentado) {
            $this->nome = $nome;
            $this->idade = $idade;
            $this->aposentado = $aposentado;
        }

        public function jsonSerialize() {
            $vars = get_object_vars($this);
            return $vars;
        }
    }
    
    $cliente = new Cliente("João",40,false);

    header('Content-Type: application/json');
    echo json_encode($cliente, JSON_UNESCAPED_UNICODE);
    die();