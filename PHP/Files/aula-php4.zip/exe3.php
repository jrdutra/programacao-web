<?php
    header('Access-Control-Allow-Origin: *');

    header('Content-Type: application/json');
    echo "Minha primeira API!";
    die();
