<?php
    header('Access-Control-Allow-Origin: *');

    echo "Minha primeira API!";
    die();
