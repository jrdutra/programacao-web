
console.log('Minha soma é: ' + (a + b));