
// Exercício 1
var tagNome = document.querySelector('#nome');
console.log(tagNome);

var botaoLogar = document.querySelector('#logar');
console.log(botaoLogar);

// Exercício 2 e 3

var notificacaoSucesso = document.querySelector('#sucesso');

botaoLogar.addEventListener('click',function(){
    var nome = tagNome.value;
    console.log('Nome do usuário: ' + nome);

    notificacaoSucesso.textContent = 'Seja bem-vindo ' + nome + '!';
})