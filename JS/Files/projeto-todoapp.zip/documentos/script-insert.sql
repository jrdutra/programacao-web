insert into tipos (descricao) values ('Trabalho'),('Lazer');

insert into usuarios (nome) values ('Guilherme');

insert into tarefas (codigoUsuario,codigoTipo,texto)
values (1,2,'Andar de bicicleta'), (1,1,'Formatar notebook');